const SESSION_COOKIE = "ws_admin_session";
const SESSION_TTL = 60 * 60 * 8;

function json(data, status = 200, headers = {}) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store", ...headers }
  });
}

function b64url(bytes) {
  let binary = "";
  for (const b of bytes) binary += String.fromCharCode(b);
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}
function fromB64url(s) {
  const raw = s.replace(/-/g, "+").replace(/_/g, "/");
  const bin = atob(raw + "=".repeat((4 - raw.length % 4) % 4));
  return Uint8Array.from(bin, c => c.charCodeAt(0));
}
async function hmac(secret, value) {
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign", "verify"]);
  return new Uint8Array(await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(value)));
}
async function signSession(env, payload) {
  const body = b64url(new TextEncoder().encode(JSON.stringify(payload)));
  const sig = b64url(await hmac(env.SESSION_SECRET, body));
  return `${body}.${sig}`;
}
async function verifySession(env, token) {
  if (!token || !env.SESSION_SECRET) return false;
  const parts = token.split(".");
  if (parts.length !== 2) return false;
  try {
    const expected = await hmac(env.SESSION_SECRET, parts[0]);
    const got = fromB64url(parts[1]);
    if (expected.length !== got.length) return false;
    let diff = 0;
    for (let i = 0; i < expected.length; i++) diff |= expected[i] ^ got[i];
    if (diff !== 0) return false;
    const payload = JSON.parse(new TextDecoder().decode(fromB64url(parts[0])));
    return payload.exp > Math.floor(Date.now() / 1000) && payload.sub === "admin";
  } catch { return false; }
}
function cookieValue(request, name) {
  const cookies = request.headers.get("Cookie") || "";
  for (const part of cookies.split(";")) {
    const i = part.indexOf("=");
    if (i > -1 && part.slice(0, i).trim() === name) return part.slice(i + 1).trim();
  }
  return "";
}
function setCookie(token, request) {
  const secure = new URL(request.url).protocol === "https:" ? "; Secure" : "";
  return `${SESSION_COOKIE}=${token}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${SESSION_TTL}${secure}`;
}
function clearCookie(request) {
  const secure = new URL(request.url).protocol === "https:" ? "; Secure" : "";
  return `${SESSION_COOKIE}=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0${secure}`;
}
function validOrigin(request) {
  const origin = request.headers.get("Origin");
  if (!origin) return true; // same-origin browser requests can omit Origin in some contexts
  try { return new URL(origin).origin === new URL(request.url).origin; } catch { return false; }
}
async function bodyJson(request) {
  const len = Number(request.headers.get("Content-Length") || 0);
  if (len > 100_000) throw new Error("请求内容过大");
  return await request.json();
}
function cleanText(v, max = 500) {
  return String(v ?? "").trim().slice(0, max);
}
function safeUrl(v, allowEmpty = false) {
  const value = cleanText(v, 2048);
  if (!value && allowEmpty) return "";
  let u;
  try { u = new URL(value); } catch { throw new Error("网址格式不正确"); }
  if (!["http:", "https:"].includes(u.protocol)) throw new Error("网址只允许 http 或 https");
  return u.toString();
}
function positiveInt(v, fallback = 0) {
  const n = Number(v);
  return Number.isInteger(n) && n >= 0 && n < 1_000_000 ? n : fallback;
}
async function requireAdmin(request, env) {
  return verifySession(env, cookieValue(request, SESSION_COOKIE));
}
async function api(request, env) {
  const url = new URL(request.url);
  const path = url.pathname.replace(/\/+$/, "") || "/";
  const method = request.method.toUpperCase();

  if (path === "/api/health" && method === "GET") return json({ ok: true });

  if (path === "/api/login" && method === "POST") {
    if (!validOrigin(request)) return json({ error: "请求来源不合法" }, 403);
    if (!env.ADMIN_PASSWORD || !env.SESSION_SECRET) return json({ error: "服务端尚未配置 ADMIN_PASSWORD 或 SESSION_SECRET" }, 500);
    let body;
    try { body = await bodyJson(request); } catch { return json({ error: "请求格式错误" }, 400); }
    const password = String(body.password ?? "");
    // Compare encoded bytes without returning any password information.
    const a = new TextEncoder().encode(password);
    const b = new TextEncoder().encode(env.ADMIN_PASSWORD);
    let diff = a.length ^ b.length;
    const max = Math.max(a.length, b.length);
    for (let i = 0; i < max; i++) diff |= (a[i] || 0) ^ (b[i] || 0);
    if (diff !== 0) return json({ error: "密码错误" }, 401);
    const now = Math.floor(Date.now() / 1000);
    const token = await signSession(env, { sub: "admin", iat: now, exp: now + SESSION_TTL });
    return json({ ok: true }, 200, { "Set-Cookie": setCookie(token, request) });
  }

  if (path === "/api/logout" && method === "POST") {
    if (!validOrigin(request)) return json({ error: "请求来源不合法" }, 403);
    return json({ ok: true }, 200, { "Set-Cookie": clearCookie(request) });
  }

  if (path === "/api/me" && method === "GET") {
    return json({ authenticated: await requireAdmin(request, env) });
  }

  if (path === "/api/public" && method === "GET") {
    try {
      const [categories, sites, settings] = await Promise.all([
        env.DB.prepare("SELECT id, name, description, sort_order FROM categories ORDER BY sort_order, id").all(),
        env.DB.prepare("SELECT id, category_id, name, url, description, icon_url, sort_order FROM sites WHERE is_enabled = 1 ORDER BY sort_order, id").all(),
        env.DB.prepare("SELECT key, value FROM settings").all()
      ]);
      return json({ categories: categories.results || [], sites: sites.results || [], settings: Object.fromEntries((settings.results || []).map(x => [x.key, x.value])) });
    } catch (e) { return json({ error: "读取数据库失败，请检查 D1 初始化与绑定" }, 500); }
  }

  if (!path.startsWith("/api/admin/")) return json({ error: "接口不存在" }, 404);
  if (!(await requireAdmin(request, env))) return json({ error: "请先登录" }, 401);
  if (method !== "GET" && !validOrigin(request)) return json({ error: "请求来源不合法" }, 403);

  try {
    if (path === "/api/admin/sites" && method === "GET") {
      const result = await env.DB.prepare("SELECT * FROM sites ORDER BY category_id, sort_order, id").all();
      return json({ sites: result.results || [] });
    }
    if (path === "/api/admin/sites" && method === "POST") {
      const b = await bodyJson(request);
      const categoryId = positiveInt(b.category_id, -1);
      const name = cleanText(b.name, 120), description = cleanText(b.description, 500);
      const siteUrl = safeUrl(b.url), iconUrl = safeUrl(b.icon_url, true);
      if (!name || categoryId < 1) return json({ error: "网站名称和分类为必填项" }, 400);
      const order = positiveInt(b.sort_order, 0), enabled = b.is_enabled === false || Number(b.is_enabled) === 0 ? 0 : 1;
      const result = await env.DB.prepare("INSERT INTO sites (category_id,name,url,description,icon_url,sort_order,is_enabled,updated_at) VALUES (?,?,?,?,?,?,?,datetime('now'))")
        .bind(categoryId, name, siteUrl, description, iconUrl, order, enabled).run();
      return json({ ok: true, id: result.meta.last_row_id }, 201);
    }
    const siteMatch = path.match(/^\/api\/admin\/sites\/(\d+)$/);
    if (siteMatch && method === "PUT") {
      const id = Number(siteMatch[1]), b = await bodyJson(request);
      const categoryId = positiveInt(b.category_id, -1), name = cleanText(b.name, 120);
      if (!name || categoryId < 1) return json({ error: "网站名称和分类为必填项" }, 400);
      await env.DB.prepare("UPDATE sites SET category_id=?,name=?,url=?,description=?,icon_url=?,sort_order=?,is_enabled=?,updated_at=datetime('now') WHERE id=?")
        .bind(categoryId, name, safeUrl(b.url), cleanText(b.description, 500), safeUrl(b.icon_url, true), positiveInt(b.sort_order, 0), (b.is_enabled === false || Number(b.is_enabled) === 0) ? 0 : 1, id).run();
      return json({ ok: true });
    }
    if (siteMatch && method === "DELETE") {
      await env.DB.prepare("DELETE FROM sites WHERE id=?").bind(Number(siteMatch[1])).run();
      return json({ ok: true });
    }

    if (path === "/api/admin/categories" && method === "GET") {
      const result = await env.DB.prepare("SELECT * FROM categories ORDER BY sort_order, id").all();
      return json({ categories: result.results || [] });
    }
    if (path === "/api/admin/categories" && method === "POST") {
      const b = await bodyJson(request), name = cleanText(b.name, 80);
      if (!name) return json({ error: "分类名称不能为空" }, 400);
      const result = await env.DB.prepare("INSERT INTO categories (name,description,sort_order) VALUES (?,?,?)")
        .bind(name, cleanText(b.description, 300), positiveInt(b.sort_order, 0)).run();
      return json({ ok: true, id: result.meta.last_row_id }, 201);
    }
    const catMatch = path.match(/^\/api\/admin\/categories\/(\d+)$/);
    if (catMatch && method === "PUT") {
      const b = await bodyJson(request), name = cleanText(b.name, 80);
      if (!name) return json({ error: "分类名称不能为空" }, 400);
      await env.DB.prepare("UPDATE categories SET name=?,description=?,sort_order=? WHERE id=?")
        .bind(name, cleanText(b.description, 300), positiveInt(b.sort_order, 0), Number(catMatch[1])).run();
      return json({ ok: true });
    }
    if (catMatch && method === "DELETE") {
      const result = await env.DB.prepare("DELETE FROM categories WHERE id=?").bind(Number(catMatch[1])).run();
      if (result.meta.changes === 0) return json({ error: "分类不存在" }, 404);
      return json({ ok: true });
    }

    if (path === "/api/admin/settings" && method === "GET") {
      const result = await env.DB.prepare("SELECT key,value FROM settings").all();
      return json({ settings: Object.fromEntries((result.results || []).map(x => [x.key, x.value])) });
    }
    if (path === "/api/admin/settings" && method === "PUT") {
      const b = await bodyJson(request);
      const allowed = {
        site_title: cleanText(b.site_title, 100),
        site_subtitle: cleanText(b.site_subtitle, 200),
        logo_url: safeUrl(b.logo_url, true),
        search_engine: safeUrl(b.search_engine),
        theme: ["indigo", "ocean", "emerald", "rose", "amber", "mono"].includes(b.theme) ? b.theme : "indigo",
        card_style: ["classic", "soft", "outline", "glass", "compact", "top-icon"].includes(b.card_style) ? b.card_style : "classic"
      };
      if (!allowed.site_title) return json({ error: "网站名称不能为空" }, 400);
      if (!allowed.search_engine.includes("{query}") && !allowed.search_engine.includes("?q=") && !allowed.search_engine.endsWith("=")) {
        return json({ error: "搜索地址需要包含查询参数，例如 https://www.google.com/search?q=" }, 400);
      }
      const stmt = env.DB.prepare("INSERT INTO settings (key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value");
      await env.DB.batch(Object.entries(allowed).map(([k,v]) => stmt.bind(k,v)));
      return json({ ok: true });
    }
    return json({ error: "接口不存在" }, 404);
  } catch (e) {
    if (String(e?.message || "").includes("UNIQUE constraint failed")) return json({ error: "名称已存在，请换一个名称" }, 409);
    if (String(e?.message || "").includes("FOREIGN KEY constraint failed")) return json({ error: "该分类仍有网站，请先移动或删除这些网站" }, 409);
    return json({ error: e?.message || "服务器内部错误" }, 400);
  }
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname.startsWith("/api/")) return api(request, env);
    if (url.pathname === "/admin") {
      return Response.redirect(new URL("/admin.html", url), 302);
    }
    return env.ASSETS.fetch(request);
  }
};
