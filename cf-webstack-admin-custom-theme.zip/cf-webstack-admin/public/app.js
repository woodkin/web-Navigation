const $ = s => document.querySelector(s);
let data = {categories:[],sites:[],settings:{}};
let activeCategory = "all";
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
function iconHtml(site) {
  const icon = site.icon_url || "";
  if (icon) return `<img src="${esc(icon)}" alt="" loading="lazy" onerror="this.parentElement.textContent='${esc((site.name||'?').slice(0,1))}'">`;
  try {
    const host = new URL(site.url).origin;
    return `<img src="${esc(host + "/favicon.ico")}" alt="" loading="lazy" onerror="this.remove();this.parentElement.textContent='${esc((site.name||'?').slice(0,1))}'">`;
  } catch { return esc((site.name||"?").slice(0,1)); }
}
function renderCategories() {
  const nav = $("#category-nav");
  nav.innerHTML = `<button class="category-chip ${activeCategory==="all"?"active":""}" data-category="all">全部网站</button>` +
    data.categories.map(c=>`<button class="category-chip ${String(activeCategory)===String(c.id)?"active":""}" data-category="${c.id}">${esc(c.name)}</button>`).join("");
  nav.querySelectorAll("button").forEach(b=>b.addEventListener("click",()=>{
    activeCategory=b.dataset.category; renderCategories(); renderSites($("#search-input").value);
    if(activeCategory!=="all" && !$("#search-input").value) document.getElementById(`category-${activeCategory}`)?.scrollIntoView({behavior:"smooth",block:"start"});
  }));
}
function renderSites(query="") {
  const content=$("#site-content"), q=query.trim().toLocaleLowerCase();
  let cats=data.categories.filter(c=>activeCategory==="all"||String(c.id)===String(activeCategory));
  const sections=cats.map(c=>{
    const sites=data.sites.filter(s=>String(s.category_id)===String(c.id)&&
      (!q || [s.name,s.description,c.name,c.description].some(v=>String(v||"").toLocaleLowerCase().includes(q))));
    if(!sites.length)return "";
    return `<section class="category-section" id="category-${c.id}"><div class="section-heading"><span class="section-dot"></span><div><h2>${esc(c.name)}</h2>${c.description?`<p>${esc(c.description)}</p>`:""}</div><span class="section-count">${sites.length} 个网站</span></div><div class="site-grid">${sites.map(s=>`<a class="site-card" href="${esc(s.url)}" target="_blank" rel="noopener noreferrer"><span class="site-icon">${iconHtml(s)}</span><span class="site-info"><h3>${esc(s.name)}</h3><p>${esc(s.description||s.url)}</p></span></a>`).join("")}</div></section>`;
  }).join("");
  content.innerHTML=sections || `<div class="empty-state"><strong>没有找到相关网站</strong>试试其他关键词，或在后台添加新网站。</div>`;
  $("#search-hint").textContent=q?`找到 ${data.sites.filter(s=>(activeCategory==="all"||String(s.category_id)===String(activeCategory))&&[s.name,s.description,(data.categories.find(c=>c.id===s.category_id)||{}).name].some(v=>String(v||"").toLowerCase().includes(q))).length} 个匹配结果`:"输入关键词快速查找";
}
async function init() {
  try {
    const r=await fetch("/api/public");
    if(!r.ok) throw new Error("API error");
    data=await r.json();
    const settings=data.settings||{};
    const title=settings.site_title||"我的导航", subtitle=settings.site_subtitle||"收集好用的网站，让效率触手可及";
    document.title=title; $("#brand-title").textContent=title; $("#hero-title").textContent=title; $("#hero-subtitle").textContent=subtitle;
    document.body.dataset.theme = ["indigo", "ocean", "emerald", "rose", "amber", "mono"].includes(settings.theme) ? settings.theme : "indigo";
    document.body.dataset.cardStyle = ["classic", "soft", "outline", "glass", "compact", "top-icon"].includes(settings.card_style) ? settings.card_style : "classic";
    if(settings.logo_url){$("#logo").src=settings.logo_url;$("#logo").classList.remove("hidden");$("#logo").onerror=()=>$("#logo").classList.add("hidden");}
    renderCategories();renderSites();
  } catch {
    $("#site-content").innerHTML='<div class="empty-state"><strong>暂时无法加载导航</strong>请检查 Cloudflare D1 数据库是否已初始化并正确绑定。</div>';
  }
}
$("#search-form").addEventListener("submit",e=>{e.preventDefault();renderSites($("#search-input").value)});
$("#search-input").addEventListener("input",()=>renderSites($("#search-input").value));
$("#theme-toggle").addEventListener("click",()=>{document.body.classList.toggle("dark");localStorage.setItem("ws-theme",document.body.classList.contains("dark")?"dark":"light")});
if(localStorage.getItem("ws-theme")==="dark")document.body.classList.add("dark");
init();
