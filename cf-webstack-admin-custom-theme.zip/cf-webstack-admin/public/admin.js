const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
let sites=[], categories=[], settings={};
const esc = s => String(s ?? "").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
async function api(path, options={}) {
  const headers={"Content-Type":"application/json",...(options.headers||{})};
  const res=await fetch(path,{...options,headers,credentials:"same-origin"});
  let body={};try{body=await res.json()}catch{}
  if(!res.ok) throw new Error(body.error||`请求失败 (${res.status})`);
  return body;
}
function toast(message,error=false){const el=$("#toast");el.textContent=message;el.classList.toggle("error",error);el.classList.remove("hidden");clearTimeout(toast.timer);toast.timer=setTimeout(()=>el.classList.add("hidden"),3500)}
function showDashboard(){ $("#login-panel").classList.add("hidden");$("#dashboard").classList.remove("hidden");$("#logout-btn").classList.remove("hidden");refreshAll(); }
function showLogin(){ $("#login-panel").classList.remove("hidden");$("#dashboard").classList.add("hidden");$("#logout-btn").classList.add("hidden"); }
async function refreshAll(){try{const [s,c,g]=await Promise.all([api("/api/admin/sites"),api("/api/admin/categories"),api("/api/admin/settings")]);sites=s.sites;categories=c.categories;settings=g.settings;renderSites();renderCategories();fillSettings();}catch(e){toast(e.message,true);}}
function categoryName(id){return categories.find(c=>Number(c.id)===Number(id))?.name||"未知分类"}
function renderSites(){
  $("#sites-table").innerHTML=sites.map(s=>`<tr><td><div class="table-site"><span class="table-site-icon">${s.icon_url?`<img src="${esc(s.icon_url)}" alt="" style="width:100%;height:100%;object-fit:cover" onerror="this.remove()">`:esc((s.name||"?").slice(0,1))}</span><span><span class="table-site-name">${esc(s.name)}</span><br><span class="table-site-url">${esc(s.url)}</span></span></div></td><td>${esc(categoryName(s.category_id))}</td><td>${s.sort_order}</td><td><span class="status-pill ${s.is_enabled?"":"off"}">${s.is_enabled?"显示中":"已隐藏"}</span></td><td><div class="row-actions"><button class="text-button" data-edit-site="${s.id}">编辑</button><button class="text-button danger" data-delete-site="${s.id}">删除</button></div></td></tr>`).join("");
  $("#sites-empty").classList.toggle("hidden",sites.length>0);
  $$("[data-edit-site]").forEach(b=>b.onclick=()=>openSiteDialog(sites.find(s=>s.id===Number(b.dataset.editSite))));
  $$("[data-delete-site]").forEach(b=>b.onclick=async()=>{const s=sites.find(x=>x.id===Number(b.dataset.deleteSite));if(!s||!confirm(`确定删除网站“${s.name}”吗？`))return;try{await api(`/api/admin/sites/${s.id}`,{method:"DELETE"});toast("网站已删除");await refreshAll()}catch(e){toast(e.message,true)}});
}
function renderCategories(){
  $("#categories-table").innerHTML=categories.map(c=>`<tr><td><strong>${esc(c.name)}</strong></td><td>${esc(c.description||"—")}</td><td>${c.sort_order}</td><td><div class="row-actions"><button class="text-button" data-edit-category="${c.id}">编辑</button><button class="text-button danger" data-delete-category="${c.id}">删除</button></div></td></tr>`).join("");
  $$("[data-edit-category]").forEach(b=>b.onclick=()=>openCategoryDialog(categories.find(c=>c.id===Number(b.dataset.editCategory))));
  $$("[data-delete-category]").forEach(b=>b.onclick=async()=>{const c=categories.find(x=>x.id===Number(b.dataset.deleteCategory));if(!c||!confirm(`确定删除分类“${c.name}”吗？`))return;try{await api(`/api/admin/categories/${c.id}`,{method:"DELETE"});toast("分类已删除");await refreshAll()}catch(e){toast(e.message,true)}});
}
function fillSettings(){$("#setting-title").value=settings.site_title||"";$("#setting-subtitle").value=settings.site_subtitle||"";$("#setting-logo").value=settings.logo_url||"";$("#setting-search").value=settings.search_engine||"https://www.google.com/search?q=";$("#setting-theme").value=settings.theme||"indigo";$("#setting-card-style").value=settings.card_style||"classic"}
function openSiteDialog(site=null){
  $("#edit-form").reset();$("#dialog-error").textContent="";$("#edit-id").value=site?.id||"";
  $("#dialog-title").textContent=site?"编辑网站":"添加网站";
  $("#edit-name").value=site?.name||"";$("#edit-url").value=site?.url||"";$("#edit-description").value=site?.description||"";$("#edit-icon").value=site?.icon_url||"";$("#edit-order").value=site?.sort_order??0;$("#edit-enabled").checked=site?!!site.is_enabled:true;
  $("#edit-category").innerHTML=categories.map(c=>`<option value="${c.id}">${esc(c.name)}</option>`).join("");
  if(site)$("#edit-category").value=site.category_id;else if(categories[0])$("#edit-category").value=categories[0].id;
  if(!categories.length){toast("请先创建至少一个分类",true);return}
  $("#edit-dialog").showModal();
}
function openCategoryDialog(c=null){
  $("#category-form").reset();$("#category-error").textContent="";$("#category-edit-id").value=c?.id||"";$("#category-dialog-title").textContent=c?"编辑分类":"添加分类";
  $("#category-name").value=c?.name||"";$("#category-description").value=c?.description||"";$("#category-order").value=c?.sort_order??0;$("#category-dialog").showModal();
}
$("#login-form").addEventListener("submit",async e=>{e.preventDefault();$("#login-error").textContent="";try{await api("/api/login",{method:"POST",body:JSON.stringify({password:$("#login-password").value})});$("#login-password").value="";showDashboard()}catch(err){$("#login-error").textContent=err.message}});
$("#logout-btn").addEventListener("click",async()=>{try{await api("/api/logout",{method:"POST"})}finally{showLogin()}});
$$("[data-tab]").forEach(b=>b.addEventListener("click",()=>{$$("[data-tab]").forEach(x=>x.classList.toggle("active",x===b));["sites","categories","settings"].forEach(k=>$(`#tab-${k}`).classList.toggle("hidden",k!==b.dataset.tab))}));
$("#add-site-btn").onclick=()=>openSiteDialog();
$("#close-dialog").onclick=$("#cancel-dialog").onclick=()=>$("#edit-dialog").close();
$("#edit-form").addEventListener("submit",async e=>{e.preventDefault();$("#dialog-error").textContent="";const id=$("#edit-id").value;const body={name:$("#edit-name").value,url:$("#edit-url").value,category_id:Number($("#edit-category").value),description:$("#edit-description").value,icon_url:$("#edit-icon").value,sort_order:Number($("#edit-order").value||0),is_enabled:$("#edit-enabled").checked};try{await api(id?`/api/admin/sites/${id}`:"/api/admin/sites",{method:id?"PUT":"POST",body:JSON.stringify(body)});$("#edit-dialog").close();toast(id?"网站已更新":"网站已添加");await refreshAll()}catch(err){$("#dialog-error").textContent=err.message}});
$("#add-category-btn").onclick=()=>openCategoryDialog();
$("#close-category-dialog").onclick=$("#cancel-category-dialog").onclick=()=>$("#category-dialog").close();
$("#category-form").addEventListener("submit",async e=>{e.preventDefault();$("#category-error").textContent="";const id=$("#category-edit-id").value;const body={name:$("#category-name").value,description:$("#category-description").value,sort_order:Number($("#category-order").value||0)};try{await api(id?`/api/admin/categories/${id}`:"/api/admin/categories",{method:id?"PUT":"POST",body:JSON.stringify(body)});$("#category-dialog").close();toast(id?"分类已更新":"分类已添加");await refreshAll()}catch(err){$("#category-error").textContent=err.message}});
$("#settings-form").addEventListener("submit",async e=>{e.preventDefault();try{await api("/api/admin/settings",{method:"PUT",body:JSON.stringify({site_title:$("#setting-title").value,site_subtitle:$("#setting-subtitle").value,logo_url:$("#setting-logo").value,search_engine:$("#setting-search").value,theme:$("#setting-theme").value,card_style:$("#setting-card-style").value})});toast("站点设置已保存");await refreshAll()}catch(err){toast(err.message,true)}});
(async()=>{try{const me=await api("/api/me");if(me.authenticated)showDashboard();else showLogin()}catch{showLogin()}})();
